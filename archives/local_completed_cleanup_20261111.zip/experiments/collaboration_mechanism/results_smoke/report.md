# Collaboration mechanism experiment report

**Scope:** This report is exploratory and is not performance confirmation for D/E.
Local uses no public update. The other branches use a fixed public budget. Self and Aggregate may follow different trajectories; their per-round curves are retained as observed.
Case summary timings are diagnostics only and do not support formal performance inferences.

Formal exploratory screening applies only when every case in the partition has `identity.preset == full`; smoke runs validate the path only and cannot determine the screening threshold.

Cases: 9. Partitions: dirichlet_0.1, dirichlet_0.5, iid.

Primary scenario: `dirichlet_0.1`; primary metric: final mean ACC. Preregistered exploratory practical threshold: 0.005 (0.5 percentage points).

The screening label requires exactly three seed-level Aggregate−Self and Aggregate−Shuffled mean-ACC differences, all positive, with each comparison's median at least 0.005. It is a screening label only; new seeds are required for confirmation.

ACC alone determines the screening label. NMI and ARI are secondary paired metrics.

## Paired seed summaries by partition

| Partition | Role | Comparison | Seeds | Median mean-ACC diff | Positive ACC seeds | ACC range | Median worst-ACC diff | Median mean-NMI diff | Positive NMI seeds | Median mean-ARI diff | Positive ARI seeds | Screening |
|---|---|---|---:|---:|---:|---|---:|---:|---:|---:|---:|---|
| dirichlet_0.1 | 主场景 | Aggregate-Self | 3 | 0.0000 | 0 | -0.0078 to 0.0000 | 0.0000 | -0.0029 | 0 | 0.0000 | 1 | smoke仅路径验证，不作门槛判定 |
| dirichlet_0.1 | 主场景 | Aggregate-Shuffled | 3 | 0.0000 | 0 | 0.0000 to 0.0000 | 0.0000 | 0.0006 | 2 | 0.0000 | 1 | smoke仅路径验证，不作门槛判定 |
| dirichlet_0.1 | 主场景 | Aggregate-Local | 3 | -0.0039 | 0 | -0.0078 to -0.0039 | 0.0000 | -0.0088 | 0 | -0.0010 | 1 | smoke仅路径验证，不作门槛判定 |
| dirichlet_0.5 | 次要场景 | Aggregate-Self | 3 | 0.0000 | 1 | 0.0000 to 0.0039 | 0.0000 | -0.0012 | 1 | -0.0003 | 1 | smoke仅路径验证，不作门槛判定 |
| dirichlet_0.5 | 次要场景 | Aggregate-Shuffled | 3 | 0.0000 | 0 | -0.0039 to 0.0000 | 0.0000 | -0.0012 | 1 | -0.0015 | 1 | smoke仅路径验证，不作门槛判定 |
| dirichlet_0.5 | 次要场景 | Aggregate-Local | 3 | 0.0000 | 1 | -0.0117 to 0.0039 | 0.0000 | -0.0013 | 1 | -0.0013 | 0 | smoke仅路径验证，不作门槛判定 |
| iid | 次要场景 | Aggregate-Self | 3 | 0.0000 | 0 | 0.0000 to 0.0000 | 0.0000 | 0.0000 | 0 | 0.0000 | 0 | smoke仅路径验证，不作门槛判定 |
| iid | 次要场景 | Aggregate-Shuffled | 3 | 0.0000 | 1 | 0.0000 to 0.0039 | 0.0000 | 0.0000 | 1 | 0.0000 | 1 | smoke仅路径验证，不作门槛判定 |
| iid | 次要场景 | Aggregate-Local | 3 | -0.0039 | 1 | -0.0117 to 0.0039 | -0.0078 | -0.0047 | 0 | -0.0009 | 1 | smoke仅路径验证，不作门槛判定 |

## Evaluation curves

The complete per-round evaluation curves for every supplied case are preserved in `summary.json`; no round or scenario is selected by its best score.
