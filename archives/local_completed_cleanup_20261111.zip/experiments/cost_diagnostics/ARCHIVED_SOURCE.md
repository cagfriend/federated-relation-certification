# 旧实验执行代码已归档

2026-10-30 按要求清理已完成、已上传的本地实验代码。结果、文档及验证记录保留；原 README 中的旧执行入口已不在工作目录中。

源码可从 `outputs/path_selection_setup_20261030/published_old_sources.zip` 或 GitHub 历史版本恢复；清理记录为同目录 `CLEANUP_RECEIPT.json`。当前新增实验见 `experiments/path_selection/README.md`。
