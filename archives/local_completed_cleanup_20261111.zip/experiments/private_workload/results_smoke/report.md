# 私有头部工作负载实验报告

所有性能对照先在同一 partition、case 和 seed 内配对，再对 seed 级结果取中位数。客户端是 seed 内观测，不视为独立 seed。三 seed 结果仅为探索性配对计时，不是独立新 seed 或隔离进程的性能确认；这里不与历史的其他机器运行时间比较。

## 配置与覆盖

| partition | case_id | seed | private_limit | public steps | methods |
|:--|:--|--:|:--|--:|:--|
| dirichlet_0.1 | m128_fixed1_priv128 | 404 | 128 | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_priv64 | 404 | 64 | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_privfull | 404 | full | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_priv128 | 505 | 128 | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_priv64 | 505 | 64 | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_privfull | 505 | full | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_priv128 | 606 | 128 | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_priv64 | 606 | 64 | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1_privfull | 606 | full | 1 | B, E, D |
| iid | m128_fixed1_priv128 | 404 | 128 | 1 | B, E, D |
| iid | m128_fixed1_priv64 | 404 | 64 | 1 | B, E, D |
| iid | m128_fixed1_privfull | 404 | full | 1 | B, E, D |
| iid | m128_fixed1_priv128 | 505 | 128 | 1 | B, E, D |
| iid | m128_fixed1_priv64 | 505 | 64 | 1 | B, E, D |
| iid | m128_fixed1_privfull | 505 | full | 1 | B, E, D |
| iid | m128_fixed1_priv128 | 606 | 128 | 1 | B, E, D |
| iid | m128_fixed1_priv64 | 606 | 64 | 1 | B, E, D |
| iid | m128_fixed1_privfull | 606 | full | 1 | B, E, D |

## D 相对 B/E 的配对成本

比值小于 1 表示 D 较快；省时为参照方法秒数减 D 秒数。下表优先显示 generation、完整 head 与 C0+head；其他阶段耗时保留在 `paired_cost.csv` 和 `summary.json`。统计以 seed 为单位。

| partition | case_id | 对照 | 指标 | 配对 seeds | D 较快次数 | 中位比值 | 中位省秒 |
|:--|:--|:--|:--|--:|--:|--:|--:|
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_B | generation_seconds | 3 | 0 | 4.5492 | -0.0008 |
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_B | head_pipeline_seconds | 3 | 0 | 1.1502 | -0.0008 |
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0019 | -0.0008 |
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_E | generation_seconds | 3 | 0 | 1.2603 | -0.0002 |
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_E | head_pipeline_seconds | 3 | 0 | 1.0884 | -0.0006 |
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_E | with_shared_preparation_seconds | 3 | 0 | 1.0004 | -0.0006 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_B | generation_seconds | 3 | 0 | 4.7388 | -0.0008 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_B | head_pipeline_seconds | 3 | 0 | 1.2348 | -0.0012 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0037 | -0.0012 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_E | generation_seconds | 3 | 0 | 1.4803 | -0.0003 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_E | head_pipeline_seconds | 3 | 0 | 1.1383 | -0.0007 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_E | with_shared_preparation_seconds | 3 | 0 | 1.0017 | -0.0007 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_B | generation_seconds | 3 | 0 | 5.1330 | -0.0009 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_B | head_pipeline_seconds | 3 | 1 | 1.1377 | -0.0011 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_B | with_shared_preparation_seconds | 3 | 1 | 1.0004 | -0.0011 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_E | generation_seconds | 3 | 0 | 1.4537 | -0.0004 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_E | head_pipeline_seconds | 3 | 1 | 1.0826 | -0.0007 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_E | with_shared_preparation_seconds | 3 | 1 | 1.0003 | -0.0007 |
| iid | m128_fixed1_priv128 | D_over_B | generation_seconds | 3 | 0 | 4.9300 | -0.0009 |
| iid | m128_fixed1_priv128 | D_over_B | head_pipeline_seconds | 3 | 0 | 1.1228 | -0.0007 |
| iid | m128_fixed1_priv128 | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0023 | -0.0007 |
| iid | m128_fixed1_priv128 | D_over_E | generation_seconds | 3 | 0 | 1.1567 | -0.0001 |
| iid | m128_fixed1_priv128 | D_over_E | head_pipeline_seconds | 3 | 0 | 1.0383 | -0.0002 |
| iid | m128_fixed1_priv128 | D_over_E | with_shared_preparation_seconds | 3 | 0 | 1.0008 | -0.0002 |
| iid | m128_fixed1_priv64 | D_over_B | generation_seconds | 3 | 0 | 3.5073 | -0.0006 |
| iid | m128_fixed1_priv64 | D_over_B | head_pipeline_seconds | 3 | 0 | 1.0930 | -0.0005 |
| iid | m128_fixed1_priv64 | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0015 | -0.0005 |
| iid | m128_fixed1_priv64 | D_over_E | generation_seconds | 3 | 0 | 1.1021 | -0.0001 |
| iid | m128_fixed1_priv64 | D_over_E | head_pipeline_seconds | 3 | 2 | 0.9755 | 0.0001 |
| iid | m128_fixed1_priv64 | D_over_E | with_shared_preparation_seconds | 3 | 2 | 0.9997 | 0.0001 |
| iid | m128_fixed1_privfull | D_over_B | generation_seconds | 3 | 0 | 4.1768 | -0.0006 |
| iid | m128_fixed1_privfull | D_over_B | head_pipeline_seconds | 3 | 0 | 1.0224 | -0.0001 |
| iid | m128_fixed1_privfull | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0005 | -0.0001 |
| iid | m128_fixed1_privfull | D_over_E | generation_seconds | 3 | 0 | 1.1124 | -0.0001 |
| iid | m128_fixed1_privfull | D_over_E | head_pipeline_seconds | 3 | 2 | 0.9703 | 0.0002 |
| iid | m128_fixed1_privfull | D_over_E | with_shared_preparation_seconds | 3 | 2 | 0.9994 | 0.0002 |

## 持久数组与通信量配对差

下表按同 case、同 seed 计算 D 减参照方法；负值表示 D 使用更少的持久数组字节或 traffic。

| partition | case_id | 对照 | paired seeds | 持久数组差中位数 bytes | traffic 差中位数 bytes |
|:--|:--|:--|--:|--:|--:|
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_B | 3 | 78784 | 0 |
| dirichlet_0.1 | m128_fixed1_priv128 | D_over_E | 3 | 0 | 0 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_B | 3 | 78784 | 0 |
| dirichlet_0.1 | m128_fixed1_priv64 | D_over_E | 3 | 0 | 0 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_B | 3 | 78784 | 0 |
| dirichlet_0.1 | m128_fixed1_privfull | D_over_E | 3 | 0 | 0 |
| iid | m128_fixed1_priv128 | D_over_B | 3 | 78784 | 0 |
| iid | m128_fixed1_priv128 | D_over_E | 3 | 0 | 0 |
| iid | m128_fixed1_priv64 | D_over_B | 3 | 78784 | 0 |
| iid | m128_fixed1_priv64 | D_over_E | 3 | 0 | 0 |
| iid | m128_fixed1_privfull | D_over_B | 3 | 78784 | 0 |
| iid | m128_fixed1_privfull | D_over_E | 3 | 0 | 0 |

## 减少私有工作负载带来的变化

下表比较同 partition/seed/M 下 reduced 与 full 私有工作负载的 B/E/D 阶段成本；该变化来自减少私有 SGD 预算，不能归因成 D 认证机制本身的贡献。认证收益只由同 case 内 D/B、D/E 配对衡量。

| partition | seed | method | private_limit | head省秒 | private省秒 | generation fraction 变化 | private steps 变化 |
|:--|--:|:--|--:|--:|--:|--:|--:|
| dirichlet_0.1 | 404 | B | 64 | 0.0035 | 0.0030 | 0.0182 | -18 |
| dirichlet_0.1 | 404 | E | 64 | 0.0036 | 0.0032 | 0.0468 | -18 |
| dirichlet_0.1 | 404 | D | 64 | 0.0036 | 0.0029 | 0.0489 | -18 |
| dirichlet_0.1 | 404 | B | 128 | 0.0033 | 0.0028 | 0.0212 | -18 |
| dirichlet_0.1 | 404 | E | 128 | 0.0032 | 0.0029 | 0.0668 | -18 |
| dirichlet_0.1 | 404 | D | 128 | 0.0033 | 0.0028 | 0.0491 | -18 |
| dirichlet_0.1 | 505 | B | 64 | 0.0033 | 0.0030 | -0.0029 | -18 |
| dirichlet_0.1 | 505 | E | 64 | 0.0031 | 0.0033 | 0.0235 | -18 |
| dirichlet_0.1 | 505 | D | 64 | 0.0039 | 0.0035 | 0.0445 | -18 |
| dirichlet_0.1 | 505 | B | 128 | 0.0021 | 0.0022 | -0.0091 | -18 |
| dirichlet_0.1 | 505 | E | 128 | 0.0025 | 0.0027 | 0.0270 | -18 |
| dirichlet_0.1 | 505 | D | 128 | 0.0033 | 0.0034 | 0.0290 | -18 |
| dirichlet_0.1 | 606 | B | 64 | 0.0025 | 0.0024 | 0.0117 | -18 |
| dirichlet_0.1 | 606 | E | 64 | 0.0033 | 0.0036 | 0.0615 | -18 |
| dirichlet_0.1 | 606 | D | 64 | 0.0006 | 0.0016 | 0.0477 | -18 |
| dirichlet_0.1 | 606 | B | 128 | 0.0026 | 0.0025 | 0.0075 | -18 |
| dirichlet_0.1 | 606 | E | 128 | 0.0031 | 0.0035 | 0.0372 | -18 |
| dirichlet_0.1 | 606 | D | 128 | 0.0018 | 0.0021 | -0.0038 | -18 |
| iid | 404 | B | 64 | 0.0014 | 0.0016 | 0.0152 | -18 |
| iid | 404 | E | 64 | 0.0023 | 0.0022 | 0.0465 | -18 |
| iid | 404 | D | 64 | 0.0023 | 0.0022 | 0.0490 | -18 |
| iid | 404 | B | 128 | -0.0002 | 0.0007 | 0.0049 | -18 |
| iid | 404 | E | 128 | 0.0008 | 0.0015 | 0.0156 | -18 |
| iid | 404 | D | 128 | -0.0002 | 0.0016 | 0.0784 | -18 |
| iid | 505 | B | 64 | 0.0028 | 0.0026 | 0.0179 | -18 |
| iid | 505 | E | 64 | 0.0013 | 0.0018 | 0.0358 | -18 |
| iid | 505 | D | 64 | 0.0024 | 0.0024 | 0.0392 | -18 |
| iid | 505 | B | 128 | 0.0018 | 0.0021 | -0.0007 | -18 |
| iid | 505 | E | 128 | 0.0010 | 0.0018 | 0.0552 | -18 |
| iid | 505 | D | 128 | 0.0011 | 0.0017 | 0.0430 | -18 |
| iid | 606 | B | 64 | 0.0010 | 0.0019 | 0.0149 | -18 |
| iid | 606 | E | 64 | 0.0008 | 0.0018 | 0.0134 | -18 |
| iid | 606 | D | 64 | 0.0002 | 0.0018 | 0.0432 | -18 |
| iid | 606 | B | 128 | 0.0003 | 0.0011 | 0.0116 | -18 |
| iid | 606 | E | 128 | 0.0006 | 0.0016 | 0.0164 | -18 |
| iid | 606 | D | 128 | 0.0002 | 0.0011 | 0.0077 | -18 |

## ACC 质量护栏：reduced 对同配置 full（逐方法）

使用各方法自身的最终指标作配对；ACC 下降不超过 0.01（1 个百分点）记为 within guardrail（含 1e-12 浮点容差）。NMI、ARI、最差客户端 ACC 和同客户端最小 ACC 变化作为描述性结果。缺少同 partition/seed/M 的 full 或必要指标时标为 pending。护栏是容忍范围，不是要求质量提升。

| partition | seed | method | private_limit | reduced | full | ACC reduced−full | 护栏 | NMI 差 | ARI 差 | 最差ACC差 | 同客户端最小ACC差 | 状态 |
|:--|--:|:--|--:|:--|:--|--:|:--|--:|--:|--:|--:|:--|
| dirichlet_0.1 | 404 | B | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0195 | False | -0.0028 | -0.0158 | 0.0312 | -0.0703 | paired |
| dirichlet_0.1 | 404 | E | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0195 | False | -0.0028 | -0.0158 | 0.0312 | -0.0703 | paired |
| dirichlet_0.1 | 404 | D | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0195 | False | -0.0028 | -0.0158 | 0.0312 | -0.0703 | paired |
| dirichlet_0.1 | 404 | B | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0078 | True | 0.0151 | -0.0135 | 0.0469 | -0.0625 | paired |
| dirichlet_0.1 | 404 | E | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0078 | True | 0.0151 | -0.0135 | 0.0469 | -0.0625 | paired |
| dirichlet_0.1 | 404 | D | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0078 | True | 0.0151 | -0.0135 | 0.0469 | -0.0625 | paired |
| dirichlet_0.1 | 505 | B | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0469 | False | -0.0738 | -0.0474 | 0.0000 | -0.0938 | paired |
| dirichlet_0.1 | 505 | E | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0469 | False | -0.0738 | -0.0474 | 0.0000 | -0.0938 | paired |
| dirichlet_0.1 | 505 | D | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0469 | False | -0.0738 | -0.0474 | 0.0000 | -0.0938 | paired |
| dirichlet_0.1 | 505 | B | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0234 | False | -0.0427 | -0.0294 | 0.0000 | -0.0469 | paired |
| dirichlet_0.1 | 505 | E | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0234 | False | -0.0427 | -0.0294 | 0.0000 | -0.0469 | paired |
| dirichlet_0.1 | 505 | D | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0234 | False | -0.0427 | -0.0294 | 0.0000 | -0.0469 | paired |
| dirichlet_0.1 | 606 | B | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0117 | False | 0.0422 | 0.0033 | 0.0078 | -0.0312 | paired |
| dirichlet_0.1 | 606 | E | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0117 | False | 0.0422 | 0.0033 | 0.0078 | -0.0312 | paired |
| dirichlet_0.1 | 606 | D | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0117 | False | 0.0422 | 0.0033 | 0.0078 | -0.0312 | paired |
| dirichlet_0.1 | 606 | B | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0156 | False | 0.0350 | -0.0043 | 0.0156 | -0.0469 | paired |
| dirichlet_0.1 | 606 | E | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0156 | False | 0.0350 | -0.0043 | 0.0156 | -0.0469 | paired |
| dirichlet_0.1 | 606 | D | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0156 | False | 0.0350 | -0.0043 | 0.0156 | -0.0469 | paired |
| iid | 404 | B | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | 0.0430 | True | 0.1216 | 0.0253 | 0.0547 | 0.0312 | paired |
| iid | 404 | E | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | 0.0430 | True | 0.1216 | 0.0253 | 0.0547 | 0.0312 | paired |
| iid | 404 | D | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | 0.0430 | True | 0.1216 | 0.0253 | 0.0547 | 0.0312 | paired |
| iid | 404 | B | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | 0.0469 | True | 0.1254 | 0.0274 | 0.0547 | 0.0391 | paired |
| iid | 404 | E | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | 0.0469 | True | 0.1254 | 0.0274 | 0.0547 | 0.0391 | paired |
| iid | 404 | D | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | 0.0469 | True | 0.1254 | 0.0274 | 0.0547 | 0.0391 | paired |
| iid | 505 | B | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | 0.0781 | True | 0.1579 | 0.0217 | 0.0703 | 0.0625 | paired |
| iid | 505 | E | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | 0.0781 | True | 0.1579 | 0.0217 | 0.0703 | 0.0625 | paired |
| iid | 505 | D | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | 0.0781 | True | 0.1579 | 0.0217 | 0.0703 | 0.0625 | paired |
| iid | 505 | B | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | 0.0742 | True | 0.1670 | 0.0181 | 0.0781 | 0.0703 | paired |
| iid | 505 | E | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | 0.0742 | True | 0.1670 | 0.0181 | 0.0781 | 0.0703 | paired |
| iid | 505 | D | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | 0.0742 | True | 0.1670 | 0.0181 | 0.0781 | 0.0703 | paired |
| iid | 606 | B | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0117 | False | -0.0420 | -0.0064 | -0.0156 | -0.0156 | paired |
| iid | 606 | E | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0117 | False | -0.0420 | -0.0064 | -0.0156 | -0.0156 | paired |
| iid | 606 | D | 64 | m128_fixed1_priv64 | m128_fixed1_privfull | -0.0117 | False | -0.0420 | -0.0064 | -0.0156 | -0.0156 | paired |
| iid | 606 | B | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0117 | False | -0.0439 | -0.0071 | -0.0234 | -0.0234 | paired |
| iid | 606 | E | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0117 | False | -0.0439 | -0.0071 | -0.0234 | -0.0234 | paired |
| iid | 606 | D | 128 | m128_fixed1_priv128 | m128_fixed1_privfull | -0.0117 | False | -0.0439 | -0.0071 | -0.0234 | -0.0234 | paired |

## 成本解释与边界

`head_pipeline_seconds` 是完整 head 流程耗时；`with_shared_preparation_seconds` 是包含共享准备的总口径。另列初始化、private、generation、exchange、public 阶段耗时。generation_fraction 与 teacher_recompute_fraction 用于解释证书生成占比和 teacher 刷新成本。新增持久数组内存及 traffic 按方法逐 case/seed 输出。隔离内存档案只在提供 profile 时报告。

私有上限只减少每轮头部 SGD 处理的样本量；编码器仍由完整私有集预训练并冻结，准备成本 C0 按完整口径计入，不能把本实验称为小私有数据集实验。这些数据用于评估主贡献的计算节省，允许小幅 ACC 回落；不将协作质量提升设为主要门槛，也不构成独立新 seed 的性能确认。

隔离内存 profiles：18。
