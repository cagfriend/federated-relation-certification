# STL-10 transfer experiment report

Dataset: **synthetic STL-10 fixture (smoke only)**. Runs: 12; preset: smoke.

Each method was run once per seed, partition and M in an independent serial process. Results are exploratory; this is not a formal independent confirmation and no C1/C2 verdict is made. Paired seed results are summarized by median and range, with win counts.

## Paired timing

| partition | case | comparison | seeds | median head ratio | range | wins | median seconds saved |
|---|---|---:|---:|---:|---:|---:|---:|
| dirichlet_0.1 | m128_fixed1_privfull | D/B | 1 | 1.1087 | 1.1087–1.1087 | 0/1 | -0.000 |
| dirichlet_0.1 | m128_fixed1_privfull | D/E | 1 | 0.7405 | 0.7405–0.7405 | 1/1 | 0.001 |
| dirichlet_0.1 | m32_fixed1_privfull | D/B | 1 | 1.1767 | 1.1767–1.1767 | 0/1 | -0.001 |
| dirichlet_0.1 | m32_fixed1_privfull | D/E | 1 | 1.0667 | 1.0667–1.0667 | 0/1 | -0.000 |
| iid | m128_fixed1_privfull | D/B | 1 | 1.1989 | 1.1989–1.1989 | 0/1 | -0.001 |
| iid | m128_fixed1_privfull | D/E | 1 | 1.0243 | 1.0243–1.0243 | 0/1 | -0.000 |
| iid | m32_fixed1_privfull | D/B | 1 | 1.2337 | 1.2337–1.2337 | 0/1 | -0.001 |
| iid | m32_fixed1_privfull | D/E | 1 | 1.1114 | 1.1114–1.1114 | 0/1 | -0.000 |

## Including shared preparation and loading

| partition | case | comparison | median cost ratio | median seconds saved |
|---|---|---|---:|---:|
| dirichlet_0.1 | m128_fixed1_privfull | D/B | 0.9999 | 0.000 |
| dirichlet_0.1 | m128_fixed1_privfull | D/E | 0.9915 | 0.002 |
| dirichlet_0.1 | m32_fixed1_privfull | D/B | 1.0010 | -0.000 |
| dirichlet_0.1 | m32_fixed1_privfull | D/E | 1.0008 | -0.000 |
| iid | m128_fixed1_privfull | D/B | 1.0002 | -0.001 |
| iid | m128_fixed1_privfull | D/E | 1.0000 | -0.000 |
| iid | m32_fixed1_privfull | D/B | 1.0003 | -0.001 |
| iid | m32_fixed1_privfull | D/E | 1.0002 | -0.001 |

## Cross-M quality sensitivity

M changes the public graph and target. This comparison is a sensitivity analysis, not a D-specific budget loss. The registered 1 percentage point ACC tolerance is reported per seed; private data, pseudo-labels, initial heads, and public SGD step budget are held fixed across M, while graph targets may differ.

| partition | seed | ACC change, larger M minus smaller M | within −1 pp |
|---|---:|---:|---|
| dirichlet_0.1 | 1001 | +0.0000 | yes |
| iid | 1001 | +0.0000 | yes |

## Per-run diagnostics

Full per-client ACC/NMI/ARI and cluster occupancy are retained in each run JSON under `metrics`; persistent traffic arrays and peak-memory descriptions are retained under each method summary. The C0 preparation and load costs are included in `with_shared_preparation_seconds`; maximum-pool preparation is shared and its original preparation cost is charged to either M. Audit/evaluation time is excluded from the head timer.
