# STL-10 transfer experiment report

Dataset: **synthetic STL-10 fixture (smoke only)**. Runs: 12; preset: smoke.

Each method was run once per seed, partition and M in an independent serial process. Results are exploratory; this is not a formal independent confirmation and no C1/C2 verdict is made. Paired seed results are summarized by median and range, with win counts.

## Paired timing

| partition | case | comparison | seeds | median head ratio | range | wins | median seconds saved |
|---|---|---:|---:|---:|---:|---:|---:|
| dirichlet_0.1 | m128_fixed1_privfull | D/B | 1 | 1.1661 | 1.1661–1.1661 | 0/1 | -0.001 |
| dirichlet_0.1 | m128_fixed1_privfull | D/E | 1 | 1.0157 | 1.0157–1.0157 | 0/1 | -0.000 |
| dirichlet_0.1 | m32_fixed1_privfull | D/B | 1 | 1.0804 | 1.0804–1.0804 | 0/1 | -0.000 |
| dirichlet_0.1 | m32_fixed1_privfull | D/E | 1 | 1.0131 | 1.0131–1.0131 | 0/1 | -0.000 |
| iid | m128_fixed1_privfull | D/B | 1 | 1.1669 | 1.1669–1.1669 | 0/1 | -0.001 |
| iid | m128_fixed1_privfull | D/E | 1 | 1.0384 | 1.0384–1.0384 | 0/1 | -0.000 |
| iid | m32_fixed1_privfull | D/B | 1 | 1.1796 | 1.1796–1.1796 | 0/1 | -0.001 |
| iid | m32_fixed1_privfull | D/E | 1 | 0.8887 | 0.8887–0.8887 | 1/1 | 0.001 |

## Cross-M quality sensitivity

M changes the public graph and target. This comparison is a sensitivity analysis, not a D-specific budget loss. The registered 1 percentage point ACC tolerance is reported per seed; private data, pseudo-labels, initial heads, and public SGD step budget are held fixed across M, while graph targets may differ.

| partition | seed | ACC change, larger M minus smaller M | within −1 pp |
|---|---:|---:|---|
| dirichlet_0.1 | 1001 | +0.0000 | yes |
| iid | 1001 | +0.0000 | yes |

## Per-run diagnostics

Full per-client ACC/NMI/ARI and cluster occupancy are retained in each run JSON under `metrics`; persistent traffic arrays and peak-memory descriptions are retained under each method summary. The C0 preparation and load costs are included in `with_shared_preparation_seconds`; maximum-pool preparation is shared and its original preparation cost is charged to either M. Audit/evaluation time is excluded from the head timer.
