# 公共预算实验报告

所有性能对照先在同一 partition、case 和 seed 内配对，再对 seed 级结果取中位数。客户端是 seed 内观测，不视为独立 seed。三 seed 结果仅为探索性配对计时，不是独立新 seed 或隔离进程的性能确认；这里不与历史的其他机器运行时间比较。

## 配置与覆盖

| partition | case_id | seed | policy | steps | methods |
|:--|:--|--:|:--|--:|:--|
| dirichlet_0.1 | m128_fixed1 | 404 | fixed | 1 | B, E, D |
| dirichlet_0.1 | m128_full | 404 | full | 4 | B, E, D |
| dirichlet_0.1 | m32_full | 404 | full | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1 | 505 | fixed | 1 | B, E, D |
| dirichlet_0.1 | m128_full | 505 | full | 4 | B, E, D |
| dirichlet_0.1 | m32_full | 505 | full | 1 | B, E, D |
| dirichlet_0.1 | m128_fixed1 | 606 | fixed | 1 | B, E, D |
| dirichlet_0.1 | m128_full | 606 | full | 4 | B, E, D |
| dirichlet_0.1 | m32_full | 606 | full | 1 | B, E, D |
| iid | m128_fixed1 | 404 | fixed | 1 | B, E, D |
| iid | m128_full | 404 | full | 4 | B, E, D |
| iid | m32_full | 404 | full | 1 | B, E, D |
| iid | m128_fixed1 | 505 | fixed | 1 | B, E, D |
| iid | m128_full | 505 | full | 4 | B, E, D |
| iid | m32_full | 505 | full | 1 | B, E, D |
| iid | m128_fixed1 | 606 | fixed | 1 | B, E, D |
| iid | m128_full | 606 | full | 4 | B, E, D |
| iid | m32_full | 606 | full | 1 | B, E, D |

## D 相对 B/E 的配对成本

比值小于 1 表示 D 较快；省时为参照方法秒数减 D 秒数。下表优先显示 generation、完整 head 与 C0+head；其他阶段耗时保留在 `paired_cost.csv` 和 `summary.json`。统计以 seed 为单位。

| partition | case_id | 对照 | 指标 | 配对 seeds | D 较快次数 | 中位比值 | 中位省秒 |
|:--|:--|:--|:--|--:|--:|--:|--:|
| dirichlet_0.1 | m128_fixed1 | D_over_B | generation_seconds | 3 | 0 | 4.5527 | -0.0006 |
| dirichlet_0.1 | m128_fixed1 | D_over_B | head_pipeline_seconds | 3 | 1 | 1.1597 | -0.0010 |
| dirichlet_0.1 | m128_fixed1 | D_over_B | with_shared_preparation_seconds | 3 | 1 | 1.0008 | -0.0010 |
| dirichlet_0.1 | m128_fixed1 | D_over_E | generation_seconds | 3 | 0 | 1.1528 | -0.0001 |
| dirichlet_0.1 | m128_fixed1 | D_over_E | head_pipeline_seconds | 3 | 0 | 1.0605 | -0.0004 |
| dirichlet_0.1 | m128_fixed1 | D_over_E | with_shared_preparation_seconds | 3 | 0 | 1.0007 | -0.0004 |
| dirichlet_0.1 | m128_full | D_over_B | generation_seconds | 3 | 0 | 4.3948 | -0.0007 |
| dirichlet_0.1 | m128_full | D_over_B | head_pipeline_seconds | 3 | 1 | 1.0606 | -0.0005 |
| dirichlet_0.1 | m128_full | D_over_B | with_shared_preparation_seconds | 3 | 1 | 1.0017 | -0.0005 |
| dirichlet_0.1 | m128_full | D_over_E | generation_seconds | 3 | 1 | 1.0758 | -0.0001 |
| dirichlet_0.1 | m128_full | D_over_E | head_pipeline_seconds | 3 | 0 | 1.0180 | -0.0002 |
| dirichlet_0.1 | m128_full | D_over_E | with_shared_preparation_seconds | 3 | 0 | 1.0003 | -0.0002 |
| dirichlet_0.1 | m32_full | D_over_B | generation_seconds | 3 | 0 | 5.5680 | -0.0006 |
| dirichlet_0.1 | m32_full | D_over_B | head_pipeline_seconds | 3 | 0 | 1.0739 | -0.0005 |
| dirichlet_0.1 | m32_full | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0015 | -0.0005 |
| dirichlet_0.1 | m32_full | D_over_E | generation_seconds | 3 | 0 | 1.2176 | -0.0001 |
| dirichlet_0.1 | m32_full | D_over_E | head_pipeline_seconds | 3 | 2 | 0.9631 | 0.0003 |
| dirichlet_0.1 | m32_full | D_over_E | with_shared_preparation_seconds | 3 | 2 | 0.9991 | 0.0003 |
| iid | m128_fixed1 | D_over_B | generation_seconds | 3 | 0 | 4.1950 | -0.0008 |
| iid | m128_fixed1 | D_over_B | head_pipeline_seconds | 3 | 0 | 1.1815 | -0.0012 |
| iid | m128_fixed1 | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0041 | -0.0012 |
| iid | m128_fixed1 | D_over_E | generation_seconds | 3 | 1 | 1.3636 | -0.0003 |
| iid | m128_fixed1 | D_over_E | head_pipeline_seconds | 3 | 1 | 1.1877 | -0.0013 |
| iid | m128_fixed1 | D_over_E | with_shared_preparation_seconds | 3 | 1 | 1.0043 | -0.0013 |
| iid | m128_full | D_over_B | generation_seconds | 3 | 0 | 5.3063 | -0.0008 |
| iid | m128_full | D_over_B | head_pipeline_seconds | 3 | 0 | 1.0444 | -0.0004 |
| iid | m128_full | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0013 | -0.0004 |
| iid | m128_full | D_over_E | generation_seconds | 3 | 1 | 1.0023 | -0.0000 |
| iid | m128_full | D_over_E | head_pipeline_seconds | 3 | 2 | 0.9915 | 0.0001 |
| iid | m128_full | D_over_E | with_shared_preparation_seconds | 3 | 2 | 0.9997 | 0.0001 |
| iid | m32_full | D_over_B | generation_seconds | 3 | 0 | 6.2388 | -0.0007 |
| iid | m32_full | D_over_B | head_pipeline_seconds | 3 | 0 | 1.2205 | -0.0014 |
| iid | m32_full | D_over_B | with_shared_preparation_seconds | 3 | 0 | 1.0046 | -0.0014 |
| iid | m32_full | D_over_E | generation_seconds | 3 | 0 | 1.3677 | -0.0002 |
| iid | m32_full | D_over_E | head_pipeline_seconds | 3 | 1 | 1.0371 | -0.0003 |
| iid | m32_full | D_over_E | with_shared_preparation_seconds | 3 | 1 | 1.0009 | -0.0003 |

## 持久数组与通信量配对差

下表按同 case、同 seed 计算 D 减参照方法；负值表示 D 使用更少的持久数组字节或 traffic。

| partition | case_id | 对照 | paired seeds | 持久数组差中位数 bytes | traffic 差中位数 bytes |
|:--|:--|:--|--:|--:|--:|
| dirichlet_0.1 | m128_fixed1 | D_over_B | 3 | 78784 | 0 |
| dirichlet_0.1 | m128_fixed1 | D_over_E | 3 | 0 | 0 |
| dirichlet_0.1 | m128_full | D_over_B | 3 | 78784 | 0 |
| dirichlet_0.1 | m128_full | D_over_E | 3 | 0 | 0 |
| dirichlet_0.1 | m32_full | D_over_B | 3 | 28096 | 0 |
| dirichlet_0.1 | m32_full | D_over_E | 3 | 0 | 0 |
| iid | m128_fixed1 | D_over_B | 3 | 78784 | 0 |
| iid | m128_fixed1 | D_over_E | 3 | 0 | 0 |
| iid | m128_full | D_over_B | 3 | 78784 | 0 |
| iid | m128_full | D_over_E | 3 | 0 | 0 |
| iid | m32_full | D_over_B | 3 | 28096 | 0 |
| iid | m32_full | D_over_E | 3 | 0 | 0 |

## 固定预算带来的预算变化

下表比较同 partition/seed/M 下 fixed 与 full 的 B/E/D 阶段成本和学生步数；该变化来自减少学生预算，不能归因成 D 认证机制本身的贡献。

| partition | seed | M | method | steps full→fixed | head省秒 | C0+head省秒 | generation fraction 变化 | public steps 变化 |
|:--|--:|--:|:--|:--|--:|--:|--:|--:|
| dirichlet_0.1 | 404 | 128 | B | 4→1 | 0.0043 | 0.0041 | 0.0154 | -18 |
| dirichlet_0.1 | 404 | 128 | E | 4→1 | 0.0031 | 0.0029 | 0.0097 | -18 |
| dirichlet_0.1 | 404 | 128 | D | 4→1 | 0.0014 | 0.0012 | 0.0583 | -18 |
| dirichlet_0.1 | 505 | 128 | B | 4→1 | 0.0012 | 0.0002 | 0.0127 | -18 |
| dirichlet_0.1 | 505 | 128 | E | 4→1 | 0.0023 | 0.0013 | 0.0231 | -18 |
| dirichlet_0.1 | 505 | 128 | D | 4→1 | 0.0025 | 0.0015 | 0.0319 | -18 |
| dirichlet_0.1 | 606 | 128 | B | 4→1 | 0.0024 | 0.0015 | 0.0030 | -18 |
| dirichlet_0.1 | 606 | 128 | E | 4→1 | 0.0020 | 0.0011 | 0.0100 | -18 |
| dirichlet_0.1 | 606 | 128 | D | 4→1 | 0.0019 | 0.0010 | 0.0136 | -18 |
| iid | 404 | 128 | B | 4→1 | -0.0023 | -0.0083 | 0.0340 | -18 |
| iid | 404 | 128 | E | 4→1 | -0.0044 | -0.0104 | 0.0116 | -18 |
| iid | 404 | 128 | D | 4→1 | -0.0028 | -0.0088 | 0.0082 | -18 |
| iid | 505 | 128 | B | 4→1 | 0.0033 | 0.0045 | 0.0122 | -18 |
| iid | 505 | 128 | E | 4→1 | 0.0026 | 0.0037 | 0.0230 | -18 |
| iid | 505 | 128 | D | 4→1 | 0.0021 | 0.0033 | 0.0163 | -18 |
| iid | 606 | 128 | B | 4→1 | 0.0019 | 0.0027 | 0.0142 | -18 |
| iid | 606 | 128 | E | 4→1 | 0.0032 | 0.0040 | 0.0066 | -18 |
| iid | 606 | 128 | D | 4→1 | 0.0011 | 0.0018 | 0.0317 | -18 |

## ACC 质量护栏：固定预算对同 M full

使用 B 的最终指标作精确配对；ACC 下降不超过 0.01（1 个百分点）记为 within guardrail（含 1e-12 浮点容差）。NMI、ARI、最差客户端 ACC 和同客户端最小 ACC 变化作为描述性结果。缺少同 partition/seed/M 的 full 或必要指标时标为 pending。护栏是容忍范围，不是要求质量提升。

| partition | seed | M | fixed | full | ACC fixed−full | 护栏 | NMI 差 | ARI 差 | 最差ACC差 | 同客户端最小ACC差 | 状态 |
|:--|--:|--:|:--|:--|--:|:--|--:|--:|--:|--:|:--|
| dirichlet_0.1 | 404 | 128 | m128_fixed1 | m128_full | 0.0195 | True | 0.0114 | 0.0163 | 0.0000 | 0.0000 | paired |
| dirichlet_0.1 | 505 | 128 | m128_fixed1 | m128_full | 0.0039 | True | 0.0189 | 0.0145 | 0.0000 | 0.0000 | paired |
| dirichlet_0.1 | 606 | 128 | m128_fixed1 | m128_full | 0.0156 | True | 0.0160 | 0.0061 | 0.0078 | 0.0078 | paired |
| iid | 404 | 128 | m128_fixed1 | m128_full | -0.0078 | True | 0.0009 | -0.0047 | 0.0000 | -0.0156 | paired |
| iid | 505 | 128 | m128_fixed1 | m128_full | 0.0000 | True | 0.0025 | -0.0003 | 0.0000 | 0.0000 | paired |
| iid | 606 | 128 | m128_fixed1 | m128_full | 0.0117 | True | 0.0114 | 0.0017 | 0.0234 | 0.0000 | paired |

## 成本解释与边界

`head_pipeline_seconds` 是完整 head 流程耗时；`with_shared_preparation_seconds` 是包含共享准备的总口径。另列初始化、private、generation、exchange、public 阶段耗时。generation_fraction 与 teacher_recompute_fraction 用于解释证书生成占比和 teacher 刷新成本。新增持久数组内存及 traffic 按方法逐 case/seed 输出。隔离内存档案只在提供 profile 时报告。

这些数据用于评估主贡献的计算节省，允许小幅 ACC 回落；不将协作质量提升设为主要门槛，也不构成独立新 seed 的性能确认。

隔离内存 profiles：18。
